const Materials = require('Materials'); // So we can find material
const Scene = require('Scene'); // Included by default
const Patches = require('Patches'); // We can get an input value from patch editor

Promise.all([ // We are using promise to load needed items first

Materials.findFirst('retouchingMat'), // find our retouching material 
Patches.outputs.getScalar('SliderVal'), // we are using "Patchers" for items that are in patches
// we are using getScalar for number and getBoolean for Boolean

Patches.outputs.getBoolean('Boolean'),

]).then((loadedItems) => { // the further script fill be executedo
//only when all itemas are loaded 

const retouchingMat = loadedItems[0]; // retouching was loaded first but we are starting with 0
const SliderVal = loadedItems[1];

const Boolean = loadedItems[2];

retouchingMat.skinSmoothingFactor = SliderVal.mul(5);  // our retouching mat has property skinSmoothingFactor
// skinSmoothingFactor will be equal to value of our slider multiplied by 5
//normal operator of multiplication "*" is not working in spark, so we have to write .mul(5) 
// when we are muötiplying by 5

retouchingMat.fullScreen = Boolean;
});